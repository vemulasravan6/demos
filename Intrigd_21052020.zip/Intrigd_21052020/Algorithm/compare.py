import pymongo
from urlparse import urlparse
import pandas as pd

digital_ocean_host = '139.59.34.216'
myclient = pymongo.MongoClient("mongodb://"+digital_ocean_host+":27017/")
mydb     = myclient["intrigd"]
mycol    = mydb["articles"]

def readExcelFiletoDictList(excelFilePath):
    final_list = []
    try:
        df = pd.read_excel(excelFilePath, keep_default_na=False)
        for i in df.index:
            # print(i)
            objectdict = {}
            for column_name in df.columns:
                objectdict[column_name] = df[column_name][i]
            # print(objectdict)
            final_list.append(objectdict)
        return final_list
    except:
        print('Failed to load ' + excelFilePath)
        return final_list

def writeExcelSheetFromDict(file_name='', ListOfDicts=[], sheet_name = 'Sheet1'):
    df = pd.DataFrame(ListOfDicts)
    writer = pd.ExcelWriter(file_name, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, sheet_name)
    writer.save()
    print 'File : '+file_name+' written successfully...'
    return

def getExtractedArticlesForRank(rank=None):
    if rank == None:
        print "Pls Input Rank.."
        return []
    myquery = {"rank": rank}
    mydoc = mycol.find(myquery)
    # article_link -> url extracted from search result
    # url -> deeplink inside google search result url
    Article_map_dict = {}
    for x in mydoc:
        # We're fixing all the urls with no base
        if urlparse(x['url']).netloc == '':
            # print x['url']
            parsed_url = urlparse(x['article_link'])
            base_url = parsed_url.scheme + '://' + parsed_url.netloc
            if x['url'][0] != '/':
                x['url'] = '/' + x['url']
            x['url'] = base_url + x['url']
            # print x['url']
            # print "="*10
        # print x['article_link']+' #### '+x['url']
        if x['keyword'] not in Article_map_dict:
            tmp_lis = []
            # Question unclear, which url needs to be considered either level-1 url or level-2 url
            tmp_lis.append(x['article_link'])
            #tmp_lis.append(x['url'])
            Article_map_dict[x['keyword']] = tmp_lis
        else:
            tmp_lis = Article_map_dict[x['keyword']]
            tmp_lis.append(x['article_link'])
            #tmp_lis.append(x['url'])
            Article_map_dict[x['keyword']] = tmp_lis
    final_result_for_rank = []
    for amd in Article_map_dict:
        tmp_dic = {}
        tmp_dic['keyword'] = amd
        # print amd
        tmp_dic['urls'] = Article_map_dict[amd]
        # print len(Article_map_dict[amd])
        # print '='*100
        tmp_dic['count'] = len(Article_map_dict[amd])
        final_result_for_rank.append(tmp_dic)
    return final_result_for_rank

def getInputArticlesForMatchYN(match_status=None):
    '''
    :param match_status: should be either y/n
    :return: results dict
    '''
    Article_map_dict = {}
    input_doc_results = readExcelFiletoDictList('/Users/sravan/Documents/Projects/Intrigd/Input/articlestaskSharavan.xlsx')
    for idr in input_doc_results:
        #filtering out 'y' cases
        if idr['y/n']==match_status:
            # print idr
            idr['keyword'] = idr['keyword'].replace('?', '')
            if idr['keyword'] not in Article_map_dict:
                tmp_lis = []
                tmp_lis.append(idr['article_link'])
                Article_map_dict[idr['keyword']] = tmp_lis
            else:
                tmp_lis = Article_map_dict[idr['keyword']]
                tmp_lis.append(idr['article_link'])
                Article_map_dict[idr['keyword']] = tmp_lis
    final_result_for_rank = []
    for amd in Article_map_dict:
        tmp_dic = {}
        tmp_dic['keyword'] = amd
        # print amd
        tmp_dic['urls'] = Article_map_dict[amd]
        # print len(Article_map_dict[amd])
        # print '='*100
        tmp_dic['count'] = len(Article_map_dict[amd])
        final_result_for_rank.append(tmp_dic)
    return final_result_for_rank

def get_final_results(rank=None):
    result_list = []
    extracted_result_set = getExtractedArticlesForRank(rank=rank)
    input_result_set     = getInputArticlesForMatchYN(match_status='y')
    for ers in extracted_result_set:
        for irs in input_result_set:
            # print ers['keyword'], irs['keyword']
            if ers['keyword'] == irs['keyword']:
                n1 = float(len(list(set(irs['urls']) & set(ers['urls']))))
                N1 = float(ers['count'])
                ratio = round(float(n1/N1),3)
                tmp_dic = {}
                tmp_dic['Keyword'] = ers['keyword']
                tmp_dic['Total number of matched Articles (n1)'] = n1
                tmp_dic['Total Filtered Articles (N1)'] = N1
                tmp_dic['Rank']  = str(rank)
                tmp_dic['Ratio'] = str(ratio)
                result_list.append(tmp_dic)
                print 'Keyword : '+ers['keyword']
                print 'Rank : '+str(rank)
                print 'Total number of matched Articles : n1 = ' + str(n1)
                print 'Total Filtered Articles : N1 = '+str(N1)
                print 'Ratio : n1/N1 = '+str(ratio)
                print '=' * 100
    return result_list

def loop_ranks():
    final_results = []
    rank = 1
    while rank<=3:
        results = get_final_results(rank)
        final_results = final_results+results
        rank+=1
    return final_results

results = loop_ranks()

writeExcelSheetFromDict(file_name='/Users/sravan/Documents/Projects/Intrigd/Output/AlgoStats.xlsx',ListOfDicts = results)
