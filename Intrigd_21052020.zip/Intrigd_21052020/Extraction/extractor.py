_author_ = 'Sravan'
import pandas as pd
import requests
import unidecode
from lxml import html
import time

def writeExcelSheetFromDict(file_name='', ListOfDicts=[], sheet_name = 'Sheet1'):
    df = pd.DataFrame(ListOfDicts)
    writer = pd.ExcelWriter(file_name, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, sheet_name)
    writer.save()
    print 'File : '+file_name+' written successfully...'
    return

def readExcelFiletoDictList(excelFilePath):
    final_list = []
    try:
        df = pd.read_excel(excelFilePath, keep_default_na=False)
        for i in df.index:
            # print(i)
            objectdict = {}
            for column_name in df.columns:
                objectdict[column_name] = df[column_name][i]
            #print(objectdict)
            final_list.append(objectdict)
        return final_list
    except:
        print('Failed to load '+excelFilePath)
        return final_list

file_path = '/Users/sravan/Documents/Projects/Intrigd/Input/articlestaskSharavan.xlsx'

final_list = readExcelFiletoDictList(file_path)

unique_keywords_from_input_file = []

for fl in final_list:
    if fl['keyword'] not in unique_keywords_from_input_file:
        unique_keywords_from_input_file.append(fl['keyword'])

result_list = []

#looping thru keywords
for keyword in unique_keywords_from_input_file:
    keyword = keyword.replace('?','')
    #looping through search results paginations
    i = 0
    page_no = 1
    while i<50:
        time.sleep(2)
        search_url = 'https://www.google.co.in/search?q='+keyword+'?&start='+str(i)
        text = requests.get(search_url).text
        text = unidecode.unidecode(text)
        tree = html.fromstring(text)
        xpath = ".//body/div[@id='main']//div[@class='kCrYT']"
        result_block = tree.xpath(xpath)
        for result in result_block:
            tmp_dic = {}
            tmp_dic['search_url']    = search_url
            tmp_dic['keyword']       = keyword
            tmp_dic['page_no']       = page_no
            tmp_dic['article_link']  = ''
            tmp_dic['article_title'] = ''
            try:
                result_url = result.xpath(".//a/@href")
                if len(result_url) > 0:
                    tmp_dic['article_link'] = result_url[0].split('q=')[1].split('&sa')[0]
            except:
                tmp_dic['article_link'] = ''
                pass
            try:
                article_title = result.xpath(".//a[@data-uch='1']")
                if len(article_title) > 0:
                    tmp_dic['article_title'] = article_title[0].xpath(".//text()")[0]
            except:
                tmp_dic['article_title'] = ''
                pass
            if tmp_dic['article_title'] == '' and  tmp_dic['article_link'] == '':
                pass
            else:
                result_list.append(tmp_dic)
        page_no+=1
        i+=10

writeExcelSheetFromDict(file_name='/Users/sravan/Documents/Projects/Intrigd/Output/GoogleResults.xlsx',ListOfDicts=result_list)