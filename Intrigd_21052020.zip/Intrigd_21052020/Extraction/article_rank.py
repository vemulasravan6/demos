_author_ = 'Sravan'
import pandas as pd
import requests
import unidecode
from lxml import html
import time
import os
from fuzzywuzzy import process
import pymongo

digital_ocean_host = '139.59.34.216'
myclient = pymongo.MongoClient("mongodb://"+digital_ocean_host+":27017/")
mydb = myclient["intrigd"]
mycol = mydb["articles"]

def writeExcelSheetFromDict(file_name='', ListOfDicts=[], sheet_name = 'Sheet1'):
    df = pd.DataFrame(ListOfDicts)
    writer = pd.ExcelWriter(file_name, engine='xlsxwriter', options={'strings_to_urls': False})
    df.to_excel(writer, sheet_name)
    writer.save()
    print 'File : '+file_name+' written successfully...'
    return

def readExcelFiletoDictList(excelFilePath):
    final_list = []
    try:
        df = pd.read_excel(excelFilePath, keep_default_na=False)
        for i in df.index:
            # print(i)
            objectdict = {}
            for column_name in df.columns:
                objectdict[column_name] = df[column_name][i]
            #print(objectdict)
            final_list.append(objectdict)
        return final_list
    except:
        print('Failed to load '+excelFilePath)
        return final_list

data_list = readExcelFiletoDictList('/Users/sravan/Documents/Projects/Intrigd/Output/GoogleResults.xlsx')

def select_top_3_urls(data_list, search_kw):
    '''
    Need some NLP Algorithm help here for more relevant findings,
    as of now going with fuzzy string search due to time constraints
    :param data_list:
    :param search_kw:
    :return:
    '''
    search_dict = {}
    for url_title_map in data_list:
        search_dict[url_title_map['url']] = url_title_map['title']
    #print search_kw
    results =  process.extract(search_kw, search_dict, limit=3)
    #print results
    result_list = []
    rank = 1
    for result in results:
        #print result
        tmp_dic = {}
        tmp_dic['url']  = result[2]
        tmp_dic['rank'] = rank
        tmp_dic['matching_title']  = result[0]
        print tmp_dic
        result_list.append(tmp_dic)
        rank+=1
    return result_list

def get_deep_links(base_url):
    title_links = []
    #visits the url, extracts hyperlinks and their titles
    urls = []
    try:
        content = requests.get(base_url).text
        tree = html.fromstring(content)
        urls = tree.xpath(".//a")
    except:
        urls = []
        pass
    if len(urls) > 0:
        text = ""
        for url in urls:
            dict = {}
            dict['title'] = ''
            dict['url']   = ''
            try:
                text_lis = url.xpath(".//text()")
                text = " ".join(text_lis)
                dict['title'] = text.rstrip().lstrip()
            except:
                dict['title'] = ""
                pass
            try:
                dict['url']  = url.xpath("./@href")[0]
            except:
                dict['url']  = ""
                pass
            #print dict

            #filtering out invalid urls
            if dict['url']!='' and dict['title']!='':
                title_links.append(dict)

            #print(text + " ### " + url)
    else:
        print 'Failed to fetch urls : ' + base_url
        pass


    return title_links

final_results = []
#running only a sample of 25, for full run need server
i=0
for item in data_list:
    print i
    i=i+1
    #print item
    #{'article_title': u"Artificial intelligence: China 'uses Taiwan for target practice' as it ...", 'Unnamed: 0': 0, 'keyword': u'Is artificial intelligence killing Chinese and Taiwanese labor', 'article_link': u'https://www.thetimes.co.uk/article/china-uses-taiwan-for-target-practice-as-it-perfects-ai-cyber-warfare-to-attack-the-west-sdn9qm8jt', 'search_url': u'https://www.google.co.in/search?q=Is artificial intelligence killing Chinese and Taiwanese labor?&start=0', 'page_no': 1}
    url         = item['article_link']
    search_kw   = item['keyword']
    title_links = get_deep_links(url)
    ranked_title_links = select_top_3_urls(title_links,search_kw)
    for rtl in ranked_title_links:
        rtl.update(item)
        print rtl
        x = mycol.insert_one(rtl)
        print x.inserted_id
        final_results.append(rtl)

writeExcelSheetFromDict(file_name='/Users/sravan/Documents/Projects/Intrigd/Output/Articles_Output_Ranks_Tagged.xlsx',ListOfDicts = final_results)

